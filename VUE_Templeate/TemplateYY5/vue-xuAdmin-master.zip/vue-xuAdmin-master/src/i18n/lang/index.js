/**
 * Created by WebStorm.
 * User: nirongxu
 * Date: 2018/12/8
 * Description: 文件描述
 */

import en from './en'
import cn from './cn'
export default {
  en,
  cn
}
