<template>
  <div>
    <p>Copyright © 2018 xuAdmin.</p>
  </div>
</template>

<script>
export default {
  name: 'bottom'
}
</script>

<style scoped>
p{
  height: 60px;
  line-height: 60px;
  text-align: left;
  font-size: 12px;
  color: #999999;
}
</style>
