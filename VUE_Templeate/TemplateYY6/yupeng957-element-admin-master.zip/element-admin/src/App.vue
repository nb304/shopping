<template>
  <router-view id="app"/>
</template>

<script>
export default {
  name: "App"
};
</script>
