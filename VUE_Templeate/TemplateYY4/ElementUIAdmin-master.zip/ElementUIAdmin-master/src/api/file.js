import {getApiUrl as G} from './init'

export default {
  fileUpload: G('FileUpload','post'),
}
