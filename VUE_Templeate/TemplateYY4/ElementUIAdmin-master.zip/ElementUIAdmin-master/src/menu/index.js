import Menu from './menu';

//这里可以根据权限做菜单过滤

export default  Menu;