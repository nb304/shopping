<template>
<div>
     <div style="margin:0 auto;width:900px;">
     <div class="zanzhu">
        <img class='zanzhu_title' src="static/img/zhifubao1.jpg">
        <img class='zanzhu_content' src="static/img/zhifubao2.jpg">
      </div>
       <div class="zanzhu">
        <!-- <img class='jinli' src="static/img/jinli.jpg"> -->
        <div class='zanzhu_title'>谢谢赞助~</div>
        <img class='zanzhu_content' src="static/img/jinli3.jpg">
      </div>
     <div class="zanzhu">
        <img class='zanzhu_title' src="static/img/weixin1.jpg">
        <img class='zanzhu_content' src="static/img/weixin2.jpg">
      </div>
      
  </div>
</div>
 
</template>
<style>
    .zanzhu{
        float: left;
    }
    .zanzhu_title{
        height:75px;
        width:300px;
        display: block;
        text-align: center;
        line-height: 75px;
        color: #505458;
        font-size: 32px;
        
    }
    .zanzhu_content{
        height:300px;
        width:298px;
        display: block;
    }
    .jinli{
        width:298px;
        height:375px;
    }
</style>