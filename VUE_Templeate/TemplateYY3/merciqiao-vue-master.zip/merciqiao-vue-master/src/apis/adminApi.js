import Axios from "axios";
/**
 * 提供组织,用户,角色等相关接口
 */
export default {
    add:function(){
        alert('add');
    },
    remove:function(){
        alert('remove');
    }
}