'use strict'
module.exports = {
  NODE_ENV: '"production"',
  MOCK: 'false'//生产环境关闭mock接口
}
